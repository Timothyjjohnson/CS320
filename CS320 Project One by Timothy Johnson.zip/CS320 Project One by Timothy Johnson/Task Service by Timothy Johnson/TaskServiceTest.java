// Timothy Johnson
// November 21st, 2024
// CS 320
// Professor Tuft

public class TaskServiceTest {
    private TaskService service;
    private Task task;

    @BeforeEach
    public void setUp() {
        service = new TaskService();
        task = new Task("12345", "Homework", "Complete math assignment");
        service.addTask(task);
    }

    @Test
    public void testAddTaskSuccess() {
        assertEquals(task, service.getTask("12345"));
    }

    @Test
    public void testAddDuplicateTask() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.addTask(new Task("12345", "Chores", "Wash the dishes"));
        });
    }

    @Test
    public void testDeleteTask() {
        service.deleteTask("12345");
        assertNull(service.getTask("12345"));
    }

    @Test
    public void testDeleteNonexistentTask() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteTask("99999");
        });
    }

    @Test
    public void testUpdateTask() {
        service.updateTask("12345", "Updated Homework", "Complete science assignment");
        Task updatedTask = service.getTask("12345");
        assertEquals("Updated Homework", updatedTask.getName());
        assertEquals("Complete science assignment", updatedTask.getDescription());
    }

    @Test
    public void testUpdateNonexistentTask() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateTask("99999", "New Task", "This is a new task");
        });
    }
}