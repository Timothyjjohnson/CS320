// Timothy Johnson
// November 21st, 2024
// CS 320
// Professor Tuft

package Test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class TaskTest {

    @Test
    public void testTaskCreationSuccess() {
        Task task = new Task("12345", "Homework", "Complete math assignment");

        assertAll("Verify all fields are correctly set",
            () -> assertEquals("12345", task.getTaskID()),
            () -> assertEquals("Homework", task.getName()),
            () -> assertEquals("Complete math assignment", task.getDescription())
        );
    }

    @Test
    public void testTaskIDTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Homework", "Complete math assignment");
        });
    }

    @Test
    public void testTaskIDCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Homework", "Complete math assignment");
        });
    }

    @Test
    public void testNameTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "This name is way too long for a task", "Complete math assignment");
        });
    }

    @Test
    public void testNameCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", null, "Complete math assignment");
        });
    }

    @Test
    public void testDescriptionTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "Homework", "This description is way too long and exceeds fifty characters");
        });
    }

    @Test
    public void testDescriptionCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "Homework", null);
        });
    }
}
