// Timothy Johnson
// December 6th, 2024
// CS 320
// Professor Tuft

public class ContactTest {

    @Test
    public void testContactCreationSuccess() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        assertAll("Contact fields",
            () -> assertEquals("12345", contact.getContactID()),
            () -> assertEquals("John", contact.getFirstName()),
            () -> assertEquals("Doe", contact.getLastName()),
            () -> assertEquals("1234567890", contact.getPhone()),
            () -> assertEquals("123 Main St", contact.getAddress())
        );
    }

    @Test
    public void testContactIDCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> 
            new Contact(null, "John", "Doe", "1234567890", "123 Main St")
        );
    }

    @Test
    public void testPhoneMustBeNumeric() {
        assertThrows(IllegalArgumentException.class, () -> 
            new Contact("12345", "John", "Doe", "12345abcde", "123 Main St")
        );
    }

    @Test
    public void testPhoneMustBeTenDigits() {
        assertThrows(IllegalArgumentException.class, () -> 
            new Contact("12345", "John", "Doe", "12345", "123 Main St")
        );
    }

    @Test
    public void testAddressMaxLength() {
        String longAddress = "This address is way too long and exceeds thirty characters.";
        assertThrows(IllegalArgumentException.class, () -> 
            new Contact("12345", "John", "Doe", "1234567890", longAddress)
        );
    }
}