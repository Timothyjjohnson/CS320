// Timothy Johnson
// December 6th, 2024
// CS 320
// Professor Tuft

public class ContactServiceTest {
    private ContactService service;
    private Contact contact;

    @BeforeEach
    public void setUp() {
        service = new ContactService();
        contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        service.addContact(contact);
    }

    @Test
    public void testAddContactSuccess() {
        assertEquals(contact, service.getContact("12345"));
    }

    @Test
    public void testAddDuplicateContact() {
        assertThrows(IllegalArgumentException.class, () -> 
            service.addContact(new Contact("12345", "Jane", "Smith", "0987654321", "456 Elm St"))
        );
    }

    @Test
    public void testDeleteContactSuccess() {
        service.deleteContact("12345");
        assertNull(service.getContact("12345"));
    }

    @Test
    public void testUpdateContactSuccess() {
        service.updateContact("12345", "Jane", "Smith", "0987654321", "456 Elm St");
        Contact updatedContact = service.getContact("12345");
        assertAll("Updated fields",
            () -> assertEquals("Jane", updatedContact.getFirstName()),
            () -> assertEquals("Smith", updatedContact.getLastName()),
            () -> assertEquals("0987654321", updatedContact.getPhone()),
            () -> assertEquals("456 Elm St", updatedContact.getAddress())
        );
    }

    @Test
    public void testUpdateNonexistentContact() {
        assertThrows(IllegalArgumentException.class, () -> 
            service.updateContact("99999", "Jane", "Smith", "0987654321", "456 Elm St")
        );
    }

    @Test
    public void testContactIDCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> 
            new Contact(null, "John", "Doe", "1234567890", "123 Main St")
        );
    }

    @Test
    public void testPhoneMustBeNumeric() {
        assertThrows(IllegalArgumentException.class, () -> 
            new Contact("12345", "John", "Doe", "12345abcde", "123 Main St")
        );
    }

    @Test
    public void testPhoneMustBeTenDigits() {
        assertThrows(IllegalArgumentException.class, () -> 
            new Contact("12345", "John", "Doe", "12345", "123 Main St")
        );
    }

    @Test
    public void testAddressMaxLength() {
        String longAddress = "This address is way too long and exceeds thirty characters.";
        assertThrows(IllegalArgumentException.class, () -> 
            new Contact("12345", "John", "Doe", "1234567890", longAddress)
        );
    }
}