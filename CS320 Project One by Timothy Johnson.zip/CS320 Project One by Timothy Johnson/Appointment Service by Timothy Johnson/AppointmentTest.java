// Timothy Johnson
// December 6th, 2024
// CS 320
// Professor Tuft

import java.util.Date;

public class AppointmentTest {

    @Test
    public void testValidAppointmentCreation() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000); // 1 day ahead
        Appointment appointment = new Appointment("123", futureDate, "Play games with my kids");

        assertAll("Valid appointment fields",
            () -> assertEquals("123", appointment.getAppointmentID()),
            () -> assertEquals(futureDate, appointment.getAppointmentDate()),
            () -> assertEquals("Play games with my kids", appointment.getDescription())
        );
    }

    @Test
    public void testAppointmentIDCannotBeNull() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);
        assertThrows(IllegalArgumentException.class, () -> 
            new Appointment(null, futureDate, "Family event")
        );
    }

    @Test
    public void testAppointmentDateCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> 
            new Appointment("123", null, "Family event")
        );
    }

    @Test
    public void testDescriptionCannotExceedMaxLength() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);
        String longDescription = "This description is way too long and exceeds fifty characters.";
        assertThrows(IllegalArgumentException.class, () -> 
            new Appointment("123", futureDate, longDescription)
        );
    }

    @Test
    public void testAppointmentIDTooLong() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);
        assertThrows(IllegalArgumentException.class, () -> 
            new Appointment("12345678901", futureDate, "Family event")
        );
    }

    @Test
    public void testPastDateThrowsException() {
        Date pastDate = new Date(System.currentTimeMillis() - 86400000); // 1 day ago
        assertThrows(IllegalArgumentException.class, () -> 
            new Appointment("123", pastDate, "Missed event")
        );
    }

    @Test
    public void testDescriptionCannotBeNull() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);
        assertThrows(IllegalArgumentException.class, () -> 
            new Appointment("123", futureDate, null)
        );
    }

    @Test
    public void testExactDescriptionLength() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);
        String exactDescription = "This description is exactly fifty characters long.";
        Appointment appointment = new Appointment("123", futureDate, exactDescription);
        assertEquals(exactDescription, appointment.getDescription());
    }
}