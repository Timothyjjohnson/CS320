// Timothy Johnson
// December 6th, 2024
// CS 320
// Professor Tuft

import java.util.Date;

public class AppointmentServiceTest {
    private AppointmentService service;
    private Appointment appointment;

    @BeforeEach
    public void setUp() {
        service = new AppointmentService();
        Date futureDate = new Date(System.currentTimeMillis() + 86400000); // 1 day ahead
        appointment = new Appointment("123", futureDate, "Spend time with kids");
        service.addAppointment(appointment);
    }

    @Test
    public void testAddAppointmentSuccess() {
        assertEquals(appointment, service.getAppointment("123"));
    }

    @Test
    public void testAddDuplicateAppointment() {
        assertThrows(IllegalArgumentException.class, () -> 
            service.addAppointment(new Appointment("123", new Date(), "Duplicate appointment"))
        );
    }

    @Test
    public void testDeleteAppointmentSuccess() {
        service.deleteAppointment("123");
        assertNull(service.getAppointment("123"));
    }

    @Test
    public void testDeleteNonexistentAppointment() {
        assertThrows(IllegalArgumentException.class, () -> 
            service.deleteAppointment("999")
        );
    }

    @Test
    public void testDeleteAppointmentTwice() {
        service.deleteAppointment("123");
        assertThrows(IllegalArgumentException.class, () -> 
            service.deleteAppointment("123")
        );
    }
}